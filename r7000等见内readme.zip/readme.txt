ssrplus相关组件for openwrt 18.16.04
适用asus-ac56u ,asus-ac68u,asus-ac87u,asus-n18u,
网件r6250,r6300-v2,r7000,r7900,r8000
tenda-ac9
dlink-dir-885l
tplink archer-c5-v2,archer-c9-v1
等设备
全部安装就行